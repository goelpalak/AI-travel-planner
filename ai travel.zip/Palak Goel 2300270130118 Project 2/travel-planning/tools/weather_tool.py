import requests
import logging
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

# Predefined coordinates for major travel destinations
CITY_COORDINATES = {
    "tokyo": {"lat": 35.6762, "lon": 139.6503, "country": "Japan"},
    "kyoto": {"lat": 35.0116, "lon": 135.7681, "country": "Japan"},
    "osaka": {"lat": 34.6937, "lon": 135.5023, "country": "Japan"},
    "paris": {"lat": 48.8566, "lon": 2.3522, "country": "France"},
    "london": {"lat": 51.5074, "lon": -0.1278, "country": "United Kingdom"},
    "rome": {"lat": 41.9028, "lon": 12.4964, "country": "Italy"},
    "florence": {"lat": 43.7696, "lon": 11.2558, "country": "Italy"},
    "venice": {"lat": 45.4408, "lon": 12.3155, "country": "Italy"},
    "new york": {"lat": 40.7128, "lon": -74.0060, "country": "United States"},
    "los angeles": {"lat": 34.0522, "lon": -118.2437, "country": "United States"},
    "singapore": {"lat": 1.3521, "lon": 103.8198, "country": "Singapore"},
    "bangkok": {"lat": 13.7563, "lon": 100.5018, "country": "Thailand"},
    "phuket": {"lat": 7.8804, "lon": 98.3923, "country": "Thailand"},
    "bali": {"lat": -8.4095, "lon": 115.1889, "country": "Indonesia"},
    "sydney": {"lat": -33.8688, "lon": 151.2093, "country": "Australia"},
    "barcelona": {"lat": 41.3851, "lon": 2.1734, "country": "Spain"},
    "madrid": {"lat": 40.4168, "lon": -3.7038, "country": "Spain"},
    "cairo": {"lat": 30.0444, "lon": 31.2357, "country": "Egypt"},
    "dubai": {"lat": 25.2048, "lon": 55.2708, "country": "United Arab Emirates"},
    "amsterdam": {"lat": 52.3676, "lon": 4.9041, "country": "Netherlands"},
    "reykjavik": {"lat": 64.1466, "lon": -21.9426, "country": "Iceland"},
    "cape town": {"lat": -33.9249, "lon": 18.4241, "country": "South Africa"},
    "rio de janeiro": {"lat": -22.9068, "lon": -43.1729, "country": "Brazil"},
    "vienna": {"lat": 48.2082, "lon": 16.3738, "country": "Austria"},
    "berlin": {"lat": 52.5200, "lon": 13.4050, "country": "Germany"},
    "munich": {"lat": 48.1351, "lon": 11.5820, "country": "Germany"},
    "swiss alps": {"lat": 46.5580, "lon": 8.5286, "country": "Switzerland"},
    "zurich": {"lat": 47.3769, "lon": 8.5417, "country": "Switzerland"},
}

# Weather code definitions from WMO
WMO_CODES = {
    0: "Clear sky",
    1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    71: "Slight snow fall", 73: "Moderate snow fall", 75: "Heavy snow fall",
    77: "Snow grains",
    80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail"
}

def get_coordinates(location: str) -> Optional[Dict[str, Any]]:
    """Helper to match city name to coordinates."""
    loc_clean = location.lower().strip()
    # Check exact match
    if loc_clean in CITY_COORDINATES:
        return CITY_COORDINATES[loc_clean]
        
    # Check partial match
    for city, coords in CITY_COORDINATES.items():
        if city in loc_clean or loc_clean in city:
            return coords
            
    return None

def fetch_weather_forecast(location: str) -> Dict[str, Any]:
    """
    Fetches real-time weather and a 5-day forecast for a given location.
    If location is not mapped or API call fails, returns a high-quality fallback.
    """
    coords = get_coordinates(location)
    
    if not coords:
        # Fallback for unmapped locations
        return get_mock_weather(location, "Location coordinates not in local database. Showing standard forecast.")

    lat, lon = coords["lat"], coords["lon"]
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode&timezone=auto"
    
    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            data = response.json()
            current = data.get("current_weather", {})
            daily = data.get("daily", {})
            
            # Map daily data
            forecast = []
            for i in range(min(5, len(daily.get("time", [])))):
                code = daily.get("weathercode", [0])[i]
                forecast.append({
                    "date": daily.get("time", [])[i],
                    "temp_max": daily.get("temperature_2m_max", [20])[i],
                    "temp_min": daily.get("temperature_2m_min", [10])[i],
                    "precipitation_prob": daily.get("precipitation_probability_max", [0])[i],
                    "condition": WMO_CODES.get(code, "Unknown")
                })
                
            w_code = current.get("weathercode", 0)
            return {
                "success": True,
                "location": f"{location.title()}, {coords['country']}",
                "latitude": lat,
                "longitude": lon,
                "current": {
                    "temp": current.get("temperature", 20),
                    "windspeed": current.get("windspeed", 0),
                    "condition": WMO_CODES.get(w_code, "Unknown"),
                    "code": w_code
                },
                "forecast": forecast,
                "note": "Real-time weather data retrieved successfully."
            }
        else:
            logger.warning(f"Weather API returned status code {response.status_code}")
    except Exception as e:
        logger.error(f"Failed to fetch real weather from Open-Meteo: {e}")
        
    return get_mock_weather(location, f"Could not connect to live weather service. Showing seasonal estimate.")

def get_mock_weather(location: str, note: str) -> Dict[str, Any]:
    """Generates realistic mock weather data depending on season/location."""
    month = datetime.now().month
    
    # Establish default temperature range based on typical weather
    # Simple logic: summer months in Northern hemisphere are hot, winter is cold
    is_summer = 6 <= month <= 8
    is_winter = month == 12 or month <= 2
    
    temp = 22
    condition = "Partly cloudy"
    forecast = []
    
    loc_lower = location.lower()
    
    if "singapore" in loc_lower or "bali" in loc_lower or "phuket" in loc_lower or "bangkok" in loc_lower:
        # Tropical
        temp = 30
        condition = "Humid and sunny"
        days_conditions = ["Passing shower", "Sunny interval", "Thunderstorm", "Partly cloudy", "Sunny"]
        max_temps = [31, 32, 30, 32, 33]
        min_temps = [25, 26, 24, 25, 26]
        precip = [60, 40, 80, 20, 10]
    elif is_summer:
        temp = 26
        condition = "Sunny"
        days_conditions = ["Sunny", "Clear sky", "Partly cloudy", "Passing shower", "Sunny"]
        max_temps = [27, 28, 26, 25, 27]
        min_temps = [16, 17, 15, 14, 16]
        precip = [0, 0, 10, 40, 5]
    elif is_winter:
        temp = 5
        condition = "Cold and overcast"
        days_conditions = ["Light snow", "Overcast", "Cold rain", "Mainly clear", "Partly cloudy"]
        max_temps = [3, 4, 6, 2, 4]
        min_temps = [-2, -1, 1, -4, -2]
        precip = [50, 20, 70, 0, 10]
    else:
        # Spring/Autumn
        temp = 15
        condition = "Mild and breezy"
        days_conditions = ["Partly cloudy", "Showers", "Sunny interval", "Mainly clear", "Overcast"]
        max_temps = [16, 14, 17, 18, 15]
        min_temps = [9, 8, 10, 11, 8]
        precip = [20, 60, 10, 0, 30]

    dates = ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5"]
    
    for i in range(5):
        forecast.append({
            "date": dates[i],
            "temp_max": max_temps[i] if 'max_temps' in locals() else temp + 2,
            "temp_min": min_temps[i] if 'min_temps' in locals() else temp - 5,
            "precipitation_prob": precip[i] if 'precip' in locals() else 20,
            "condition": days_conditions[i] if 'days_conditions' in locals() else condition
        })
        
    return {
        "success": True,
        "location": location.title(),
        "latitude": 0.0,
        "longitude": 0.0,
        "current": {
            "temp": temp,
            "windspeed": 12,
            "condition": condition,
            "code": 1
        },
        "forecast": forecast,
        "note": note
    }
