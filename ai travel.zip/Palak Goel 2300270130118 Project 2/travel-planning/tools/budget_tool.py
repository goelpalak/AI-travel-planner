import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

# Daily costs database by Tier: (Accommodation, Food, Transit, Activities) in INR (Indian Rupees)
COST_TIERS = {
    "tier_1": { # Very High (e.g. Delhi, Mumbai, New York, London, Paris, Tokyo)
        "budget": {"hotel": 1500, "food": 500, "transit": 200, "activities": 300},
        "mid_range": {"hotel": 4500, "food": 1500, "transit": 800, "activities": 1000},
        "luxury": {"hotel": 12000, "food": 4000, "transit": 2500, "activities": 3000},
        "flight_est": 15000
    },
    "tier_2": { # High (e.g. Bangalore, Hyderabad, Pune, Goa, Sydney, Rome, Dubai)
        "budget": {"hotel": 1200, "food": 400, "transit": 150, "activities": 200},
        "mid_range": {"hotel": 3000, "food": 1200, "transit": 600, "activities": 700},
        "luxury": {"hotel": 8000, "food": 3000, "transit": 2000, "activities": 2000},
        "flight_est": 10000
    },
    "tier_3": { # Medium (e.g. Dehradun, Jaipur, Chandigarh, Lucknow, Cape Town)
        "budget": {"hotel": 800, "food": 300, "transit": 100, "activities": 150},
        "mid_range": {"hotel": 2000, "food": 800, "transit": 400, "activities": 500},
        "luxury": {"hotel": 5000, "food": 2000, "transit": 1200, "activities": 1500},
        "flight_est": 6000
    },
    "tier_4": { # Low (e.g. Rishikesh, Mussoorie, Haridwar, Dharamshala, Bali)
        "budget": {"hotel": 600, "food": 250, "transit": 80, "activities": 100},
        "mid_range": {"hotel": 1500, "food": 600, "transit": 300, "activities": 400},
        "luxury": {"hotel": 4000, "food": 1500, "transit": 1000, "activities": 1000},
        "flight_est": 4000
    }
}

# Map common cities to tiers
CITY_TIERS = {
    "delhi": "tier_1",
    "mumbai": "tier_1",
    "new york": "tier_1",
    "london": "tier_1",
    "paris": "tier_1",
    "tokyo": "tier_1",
    
    "bangalore": "tier_2",
    "bengaluru": "tier_2",
    "pune": "tier_2",
    "hyderabad": "tier_2",
    "goa": "tier_2",
    "dubai": "tier_2",
    "rome": "tier_2",
    
    "dehradun": "tier_3",
    "jaipur": "tier_3",
    "chandigarh": "tier_3",
    "lucknow": "tier_3",
    "phuket": "tier_3",
    
    "rishikesh": "tier_4",
    "mussoorie": "tier_4",
    "haridwar": "tier_4",
    "dharamshala": "tier_4",
    "bali": "tier_4",
}

def calculate_trip_budget(
    destination: str, 
    duration_days: int = 5, 
    travel_style: str = "mid_range", 
    num_travelers: int = 1
) -> Dict[str, Any]:
    """
    Calculates estimated trip budget by category in INR.
    """
    dest_clean = destination.lower().strip()
    style_clean = travel_style.lower().strip()
    
    # Standardize styles
    if style_clean not in ["budget", "mid_range", "luxury"]:
        style_clean = "mid_range"
        
    # Standardize duration and travelers
    duration_days = max(1, duration_days)
    num_travelers = max(1, num_travelers)
    
    # Check if domestic Indian trip
    indian_keywords = ["delhi", "dehradun", "mumbai", "bengaluru", "bangalore", "pune", "hyderabad", "goa", "jaipur", "mussoorie", "rishikesh", "haridwar", "dharamshala", "lucknow", "chandigarh", "shimla", "manali", "kerala", "agra", "india"]
    is_domestic = any(kw in dest_clean for kw in indian_keywords)
    
    # Scale cost multiplier for international destinations
    cost_multiplier = 1.0 if is_domestic else 6.5
    flight_multiplier = 1.0 if is_domestic else 10.0
    
    # Determine cost tier
    tier_name = "tier_3" # Default is Tier 3 (Medium cost)
    for city, tier in CITY_TIERS.items():
        if city in dest_clean or dest_clean in city:
            tier_name = tier
            break
            
    tier_costs = COST_TIERS[tier_name]
    daily_rates = tier_costs[style_clean]
    
    # Calculate costs (with multiplier)
    num_rooms = (num_travelers + 1) // 2
    
    daily_hotel = int(daily_rates["hotel"] * num_rooms * cost_multiplier)
    daily_food = int(daily_rates["food"] * num_travelers * cost_multiplier)
    daily_transit = int(daily_rates["transit"] * num_travelers * cost_multiplier)
    daily_activities = int(daily_rates["activities"] * num_travelers * cost_multiplier)
    
    # Totals
    total_hotel = daily_hotel * duration_days
    total_food = daily_food * duration_days
    total_transit = daily_transit * duration_days
    total_activities = daily_activities * duration_days
    
    # Flights baseline estimation
    flight_cost_per_person = int(tier_costs["flight_est"] * flight_multiplier)
    total_flights = flight_cost_per_person * num_travelers
    
    # Misc buffer (10% of standard travel expenses)
    misc_buffer = int((total_hotel + total_food + total_transit + total_activities) * 0.10)
    
    grand_total_no_flights = total_hotel + total_food + total_transit + total_activities + misc_buffer
    grand_total_with_flights = grand_total_no_flights + total_flights
    
    return {
        "success": True,
        "destination": destination.title(),
        "duration_days": duration_days,
        "travel_style": travel_style.replace("_", " ").title(),
        "num_travelers": num_travelers,
        "pricing_tier": tier_name.replace("_", " ").upper(),
        "currency_code": "INR",
        "daily_breakdown": {
            "accommodation": daily_hotel,
            "food": daily_food,
            "transport": daily_transit,
            "activities": daily_activities,
            "total_daily": daily_hotel + daily_food + daily_transit + daily_activities
        },
        "total_breakdown": {
            "accommodation": total_hotel,
            "food": total_food,
            "transport": total_transit,
            "activities": total_activities,
            "flights_estimate": total_flights,
            "misc_buffer": misc_buffer,
        },
        "totals": {
            "total_excluding_flights": grand_total_no_flights,
            "total_including_flights": grand_total_with_flights,
            "average_per_person_day": int(grand_total_no_flights / (duration_days * num_travelers))
        },
        "note": f"Estimates are based on general historical indexes for {destination.title()} in INR."
    }
