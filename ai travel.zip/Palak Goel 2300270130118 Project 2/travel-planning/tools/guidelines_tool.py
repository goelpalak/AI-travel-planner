import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

GUIDELINES_DATABASE = {
    "japan": {
        "visa": "Visa-free for up to 90 days for tourists from 68 countries (including USA, Canada, EU, UK). Standard tourist e-visa required for others.",
        "safety": "Very Safe. Exercise normal safety precautions. Low crime rate. Be prepared for occasional earthquakes by reading hotel safety cards.",
        "plugs": "Type A & B (100V, 50/60Hz). Bring a universal adapter.",
        "emergency": "Police: 110, Ambulance/Fire: 119",
        "attractions": [
            {"name": "Fushimi Inari Shrine (Kyoto)", "desc": "Famous Shinto shrine with thousands of vibrant orange torii gates lining a mountain path."},
            {"name": "Mount Fuji", "desc": "Japan's iconic snow-capped volcano and highest peak, offering scenic views and climbing paths."},
            {"name": "Shibuya Crossing (Tokyo)", "desc": "The world's busiest pedestrian scramble, surrounded by neon signs and giant video screens."}
        ]
    },
    "tokyo": "japan",
    "kyoto": "japan",
    "osaka": "japan",
    
    "france": {
        "visa": "Schengen Visa rules apply. US, UK, and Canadian passport holders enjoy 90 days visa-free entry.",
        "safety": "Generally Safe. Watch out for pickpockets in crowded tourist areas, public transport, and train stations. Exercise standard caution.",
        "plugs": "Type C & E (230V, 50Hz).",
        "emergency": "European Emergency Number: 112, Police: 17, Ambulance: 15",
        "attractions": [
            {"name": "Eiffel Tower (Paris)", "desc": "The iron lattice monument that dominates the skyline of Paris, iconic symbol of France."},
            {"name": "Louvre Museum (Paris)", "desc": "The world's largest art museum, home to the Mona Lisa and Venus de Milo."},
            {"name": "Palace of Versailles", "desc": "The opulent royal residence built by Louis XIV, famous for its Hall of Mirrors and grand gardens."}
        ]
    },
    "paris": "france",
    
    "italy": {
        "visa": "Schengen Visa rules apply. 90 days visa-free entry for EU, US, UK, and Canadian nationals.",
        "safety": "Generally Safe. High incidence of minor thefts (pickpocketing) in major historical hubs like Rome, Florence, and Venice.",
        "plugs": "Type C, F & L (230V, 50Hz).",
        "emergency": "European Emergency Number: 112, Police: 113, Ambulance: 118",
        "attractions": [
            {"name": "Colosseum (Rome)", "desc": "The largest ancient amphitheater ever built, situated in the heart of Rome."},
            {"name": "Venice Canals", "desc": "A labyrinth of historic waterways lined with gothic palaces, navigated by traditional gondolas."},
            {"name": "Florence Duomo", "desc": "The magnificent cathedral with Brunelleschi's red-tiled dome, a renaissance architectural masterpiece."}
        ]
    },
    "rome": "italy",
    "venice": "italy",
    "florence": "italy",
    
    "united kingdom": {
        "visa": "Visa-free entry for citizens of the US, Canada, EU, and select countries for up to 6 months. Others must apply for a Standard Visitor Visa.",
        "safety": "Safe. Standard precautions apply. Stay alert in busy subway tubes and late at night in entertainment districts.",
        "plugs": "Type G (230V, 50Hz) - standard three-pin UK plugs.",
        "emergency": "Police/Ambulance: 999 or 112",
        "attractions": [
            {"name": "British Museum (London)", "desc": "A public institution dedicated to human history, art, and culture, housing the Rosetta Stone."},
            {"name": "Tower of London", "desc": "Historic fortress and castle on the River Thames, home to the Crown Jewels."},
            {"name": "Stonehenge", "desc": "Prehistoric monument of standing stones in Wiltshire, dating back over 4,000 years."}
        ]
    },
    "london": "united kingdom",
    
    "united states": {
        "visa": "Requires ESTA (Electronic System for Travel Authorization) for Visa Waiver Program countries, or a B1/B2 Tourist Visa.",
        "safety": "Generally Safe. Be mindful of neighborhood safety ratings. Safeguard your luggage and avoid leaving valuables visible in cars.",
        "plugs": "Type A & B (120V, 60Hz).",
        "emergency": "All emergencies: 911",
        "attractions": [
            {"name": "Statue of Liberty (New York)", "desc": "The colossal neoclassical sculpture on Liberty Island in New York Harbor."},
            {"name": "Grand Canyon (Arizona)", "desc": "A steep-sided canyon carved by the Colorado River, famous for its massive scale and red rock views."},
            {"name": "Golden Gate Bridge (San Francisco)", "desc": "The famous orange suspension bridge stretching across the Golden Gate strait."}
        ]
    },
    "new york": "united states",
    "los angeles": "united states",
    
    "thailand": {
        "visa": "Visa-free exemption for tourists from 93 countries (including USA, UK, EU) for up to 60 days. Others can get Visa on Arrival.",
        "safety": "Safe. Minor tourist scams (inflated tuk-tuk fares) are common. Respect local customs, especially regarding the Royal Family and temples.",
        "plugs": "Type A, B, C & O (220V, 50Hz).",
        "emergency": "Tourist Police (English): 1155, General: 191",
        "attractions": [
            {"name": "Grand Palace (Bangkok)", "desc": "A spectacular complex of royal buildings and ornate temples, including Wat Phra Kaew."},
            {"name": "Phi Phi Islands (Phuket)", "desc": "Stunning archipelago featuring dramatic limestone cliffs and crystal turquoise bays."},
            {"name": "Wat Arun (Bangkok)", "desc": "The iconic Temple of Dawn situated on the banks of the Chao Phraya River, covered in porcelain."}
        ]
    },
    "bangkok": "thailand",
    "phuket": "thailand",
    
    "indonesia": {
        "visa": "Visa on Arrival (VoA) is required for most nationalities, costing approx. USD 35, valid for 30 days (extendable once).",
        "safety": "Safe. Natural hazards (volcanoes, high ocean currents) exist. Rent scooters only if licensed and wearing a helmet.",
        "plugs": "Type C & F (230V, 50Hz).",
        "emergency": "Police: 110, Ambulance: 118",
        "attractions": [
            {"name": "Ubud Monkey Forest (Bali)", "desc": "Sacred sanctuary and forest inhabited by hundreds of grey long-tailed macaques."},
            {"name": "Tanah Lot Temple (Bali)", "desc": "An ancient Hindu pilgrimage temple perched on a dramatic rock formation out in the sea."},
            {"name": "Borobudur Temple", "desc": "The world's largest Buddhist temple, situated in Java, featuring beautiful stone stupas."}
        ]
    },
    "bali": "indonesia",
    
    "australia": {
        "visa": "All visitors require an Electronic Travel Authority (ETA) or a visitor visa prior to boarding their flight.",
        "safety": "Very Safe. Primary precaution: pay close attention to swim safety flags at beaches (swim between the red and yellow flags).",
        "plugs": "Type I (230V, 50Hz).",
        "emergency": "Police/Ambulance/Fire: 000",
        "attractions": [
            {"name": "Sydney Opera House", "desc": "Multi-venue performing arts center on Sydney Harbour, iconic sail-shaped modern design."},
            {"name": "Great Barrier Reef", "desc": "The world's largest coral reef system, rich in marine life and popular for diving."},
            {"name": "Uluru (Ayers Rock)", "desc": "The massive sandstone monolith in the Northern Territory desert, sacred to Indigenous Australians."}
        ]
    },
    "sydney": "australia",
    
    "egypt": {
        "visa": "Visa on Arrival available for EU, US, UK passport holders. Others must apply online or via embassy.",
        "safety": "Exercise Increased Caution. Stay in well-guarded tourist areas. Avoid unlicensed street guides and keep belongings secure.",
        "plugs": "Type C & F (220V, 50Hz).",
        "emergency": "Police: 122, Ambulance: 123",
        "attractions": [
            {"name": "Pyramids of Giza (Cairo)", "desc": "The ancient royal tomb structures, including the Great Sphinx, the last remaining Wonder of the Ancient World."},
            {"name": "Karnak Temple (Luxor)", "desc": "A vast open-air museum of ancient Egyptian temples, pylons, and hypostyle halls."},
            {"name": "Abu Simbel Temples", "desc": "Two massive rock-cut temples in southern Egypt, carved out of the mountainside during Rameses II's reign."}
        ]
    },
    "cairo": "egypt"
}

def retrieve_travel_guidelines(location: str) -> Dict[str, Any]:
    """
    Returns general guidelines, safety, visa details, and attractions for a given city or country.
    """
    loc_clean = location.lower().strip()
    
    # Check if domestic Indian trip
    indian_keywords = ["delhi", "dehradun", "mumbai", "bengaluru", "bangalore", "pune", "hyderabad", "goa", "jaipur", "mussoorie", "rishikesh", "haridwar", "dharamshala", "lucknow", "chandigarh", "shimla", "manali", "kerala", "agra", "india"]
    is_domestic = any(kw in loc_clean for kw in indian_keywords)
    
    # Try exact match
    guideline = GUIDELINES_DATABASE.get(loc_clean)
    
    # If the key points to another key (e.g. "tokyo" -> "japan")
    if isinstance(guideline, str):
        guideline = GUIDELINES_DATABASE.get(guideline)
        
    if not guideline:
        # Check partial match
        for key, val in GUIDELINES_DATABASE.items():
            if key in loc_clean or loc_clean in key:
                if isinstance(val, str):
                    guideline = GUIDELINES_DATABASE.get(val)
                else:
                    guideline = val
                break
                
    if guideline:
        return {
            "success": True,
            "location": location.title(),
            "visa_requirements": "No visa required for domestic travel within India. Carry a government photo ID." if is_domestic else guideline["visa"],
            "safety_advisory": guideline["safety"],
            "power_sockets": guideline["plugs"],
            "emergency_numbers": guideline["emergency"],
            "top_attractions": guideline["attractions"],
            "note": "Standard travel advisory guidelines parsed successfully."
        }
        
    # Domestic Indian fallback
    if is_domestic:
        attractions = [
            {"name": "Local Market & Shopping Lane", "desc": "Explore regional handcrafts, local street foods, and traditional bazaars."},
            {"name": "Scenic Viewpoint / Nature Park", "desc": "Visit mountain viewing points, local parks, or historic temples."},
            {"name": "Cultural Center & Heritage Spot", "desc": "Explore historical temples, structures, and regional architecture."}
        ]
        
        # Customized attractions for some common cities
        if "delhi" in loc_clean:
            attractions = [
                {"name": "India Gate & Kartavya Path", "desc": "The war memorial archway situated in the heart of New Delhi, surrounded by beautiful lawns."},
                {"name": "Qutub Minar Complex", "desc": "A UNESCO World Heritage Site featuring a 73-meter tall red sandstone tower and ancient iron pillar."},
                {"name": "Lotus Temple", "desc": "The prominent Bahai House of Worship shaped like a lotus flower, offering a silent meditation space."}
            ]
        elif "dehradun" in loc_clean:
            attractions = [
                {"name": "Robber's Cave (Guchhupani)", "desc": "A natural river cave formation where cold spring waters flow between high limestone walls."},
                {"name": "Sahastradhara Springs", "desc": "Sulfur water springs and caves surrounded by terraced waterfalls, popular for therapeutic baths."},
                {"name": "Forest Research Institute (FRI)", "desc": "A grand heritage university building featuring Greco-Roman architecture and forestry museums."}
            ]
        elif "mussoorie" in loc_clean:
            attractions = [
                {"name": "Kempty Falls", "desc": "A famous high waterfall cascade creating a cold mountain pool for tourists to swim and relax."},
                {"name": "Gun Hill & Ropeway", "desc": "The second highest peak in Mussoorie, offering panoramic views of the Himalayan range and Doon Valley."},
                {"name": "Lal Tibba Scenic View", "desc": "The highest point in Mussoorie featuring binoculars for viewing snow-capped Himalayan peaks."}
            ]
            
        return {
            "success": True,
            "location": location.title(),
            "visa_requirements": "No visa required for domestic travel within India. Carry Aadhaar Card or PAN Card.",
            "safety_advisory": "Generally safe. Exercise normal safety precautions. Keep emergency contacts handy.",
            "power_sockets": "Type C, D & M (230V, 50Hz) - standard Indian sockets.",
            "emergency_numbers": "National Emergency: 112, Police: 100, Ambulance: 102",
            "top_attractions": attractions,
            "note": "Indian domestic guidelines generated successfully."
        }
        
    # Generic fallback
    return {
        "success": True,
        "location": location.title(),
        "visa_requirements": "General tourist visa may be required. Check with your local embassy before travel.",
        "safety_advisory": "Exercise normal safety precautions. Keep copy of your passport in a secure digital space.",
        "power_sockets": "Varies by country. Standard universal travel adapter recommended.",
        "emergency_numbers": "General emergency numbers are usually 112 (Europe), 911 (US/Americas), or 110 (Asia).",
        "top_attractions": [
            {"name": "City Center & Historic Quarter", "desc": "Explore the cultural architecture, museum galleries, and local pedestrian walkways."},
            {"name": "Scenic Viewpoint / Nature Park", "desc": "Visit local botanical gardens or panoramic observation towers for the best sights."},
            {"name": "Local Dining District", "desc": "Savor authentic regional cuisine and street markets in popular neighborhood squares."}
        ],
        "note": "General guidelines template shown (specific destination details not found in database)."
    }
