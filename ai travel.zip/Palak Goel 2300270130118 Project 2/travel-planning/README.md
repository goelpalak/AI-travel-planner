# AI Smart Travel Planning Assistant (Agentic AI & RAG)

A premium, modern, pure Python travel advisory application built using **Streamlit** for the frontend, coupled with local agentic services for processing travel guide PDFs, a local vector database index, and a Multi-Agent workflow.

---

## 🚀 Key Features

* **Agentic Chat Workspace**: A chat interface showing step-by-step agent execution thought processes, RAG document references, and cited source excerpts.
* **Document Knowledge Hub**: A section to upload travel guide PDFs which are segmented into overlapping chunks, vectorized, and indexed.
* **Visual Itinerary Timeline Builder**: Form inputs that generate a day-by-day travel plan, accompanied by live weather conditions and estimated trip expenses.
* **Destination Comparer**: Side-by-side comparative matrices showcasing safety alerts, requirements, cost graphs, and recommendation details.
* **Interactive Budget Calculator**: Expense breakdown charts displaying food, transport, lodging, and sightseeing ratios via a custom SVG doughnut chart.
* **API Configuration Settings**: Allows entering custom Gemini API Keys or running completely offline in **Demo Mock Mode**.

---

## 🛠️ Technology Stack

* **Frontend & Core Layout**: Streamlit (Python) styled with custom CSS overrides for dark-mode glassmorphism.
* **Data & Extraction**: PyPDF2 (PDF text extraction), NumPy (vector computations and cosine similarity).
* **AI & Agentic Orchestration**: Google Generative AI Python SDK (Gemini 1.5 Flash/Pro), custom single/multi-agent routing algorithms.
* **Tools**: Open-Meteo API integrations for real-time weather, itemized trip budget calculators.

---

## 🏃 Running the Application

To run the unified Streamlit application:

```bash
# Install dependencies
pip install -r requirements.txt

# Start the Streamlit application
streamlit run app.py
```

*The application will boot up and automatically open in your default browser at [http://localhost:8501](http://localhost:8501).*

---

## 💡 How the Agentic RAG Workflow Works

1. **Router Agent**: Analyzes your query (using Gemini 1.5 JSON schema generation) to categorize the request and extract parameters (e.g. destinations, length of trip, travel style, travelers count).
2. **Tool Execution**:
   * **Weather Agent** queries the Open-Meteo API for real-time and 5-day forecasts.
   * **Budget Agent** computes detailed category expenses.
   * **Guidelines Agent** parses safety and visa advisory lists.
   * **RAG Retrieval Agent** queries the vector store index (using Gemini embeddings or fallback keyword similarities).
3. **Synthesis Agent**: Merges all tool data and document references, compiles inline source citations like `[source: guide.pdf, p. 12]`, and delivers a structured Markdown layout.
