import streamlit as st
import os
import shutil
from pathlib import Path
from datetime import datetime

from config import settings
from services.pdf_service import extract_text_chunks_from_pdf
from services.vector_store import vector_store
from services.agent_service import agent_service
from tools.weather_tool import fetch_weather_forecast
from tools.budget_tool import calculate_trip_budget
from tools.guidelines_tool import retrieve_travel_guidelines

# 1. Page Configuration
st.set_page_config(
    page_title="BharatYatra AI - Smart Travel Planning Assistant",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# 2. CSS Styles for a clean, professional corporate theme (no emojis, no glowing backgrounds)
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');

h1, h2, h3, h4 {
    font-family: 'Outfit', sans-serif !important;
    font-weight: 600;
}
.stApp, div[data-baseweb="select"] {
    font-family: 'Plus Jakarta Sans', sans-serif !important;
}
.stApp {
    background: linear-gradient(180deg, #090d16 0%, #111827 100%) !important;
    color: #f1f5f9;
}
.glass-card {
    background-color: rgba(30, 41, 59, 0.75);
    border: 1px solid rgba(99, 102, 241, 0.2);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
}
.metric-box {
    background-color: rgba(15, 23, 42, 0.6);
    border: 1px solid rgba(99, 102, 241, 0.15);
    border-radius: 6px;
    padding: 12px;
    text-align: center;
}
div.stButton > button {
    background: linear-gradient(135deg, #4f46e5 0%, #10b981 100%) !important;
    color: white !important;
    border: none !important;
    border-radius: 6px !important;
    font-weight: 600 !important;
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.25) !important;
    transition: all 0.2s ease-in-out !important;
    width: 100%;
}
div.stButton > button:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3) !important;
}
.user-bubble {
    background-color: rgba(79, 70, 229, 0.12);
    border: 1px solid rgba(79, 70, 229, 0.25);
    padding: 12px;
    border-radius: 8px 8px 0 8px;
    margin-bottom: 12px;
    max-width: 90%;
    margin-left: auto;
}
.agent-bubble {
    background-color: rgba(30, 41, 59, 0.85);
    border: 1px solid rgba(99, 102, 241, 0.15);
    padding: 12px;
    border-radius: 8px 8px 8px 0;
    margin-bottom: 12px;
    max-width: 90%;
}
.timeline-block {
    position: relative;
    padding-left: 20px;
    border-left: 2px solid #10b981;
    padding-bottom: 15px;
}
.timeline-dot {
    position: absolute;
    left: -6px;
    top: 5px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: #10b981;
    border: 2px solid #090d16;
}
</style>
""", unsafe_allow_html=True)

# 3. Session State Initializers
if 'api_key' not in st.session_state or not st.session_state.api_key:
    st.session_state.api_key = settings.DEFAULT_GEMINI_API_KEY
if 'model_name' not in st.session_state:
    st.session_state.model_name = settings.DEFAULT_MODEL_NAME
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = [
        {
            "sender": "assistant",
            "text": "Welcome to the Travel Assistant AI. \n\n**Instructions:**\n1. Upload travel guide PDFs in the left column.\n2. Ask questions about your guides or plan details in the right workspace tabs.",
            "logs": [],
            "sources": []
        }
    ]

# 4. Document Helper Functions
def get_indexed_docs():
    doc_stats = {}
    for chunk in vector_store.chunks:
        src = chunk["metadata"]["source"]
        page = chunk["metadata"]["page"]
        if src not in doc_stats:
            doc_stats[src] = {"filename": src, "pages": set(), "chunks": 0}
        doc_stats[src]["pages"].add(page)
        doc_stats[src]["chunks"] += 1
    return [{"filename": v["filename"], "page_count": len(v["pages"]), "chunk_count": v["chunks"]} for v in doc_stats.values()]

indexed_files = get_indexed_docs()
total_docs = len(indexed_files)
total_chunks = len(vector_store.chunks)

# Header Title
st.markdown("""
<div style="margin-bottom: 25px; border-bottom: 1px solid rgba(99, 102, 241, 0.15); padding-bottom: 12px;">
    <h1 style="margin: 0; font-size: 2.2rem; background: linear-gradient(135deg, #818cf8 0%, #34d399 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">BharatYatra AI</h1>
    <p style="margin: 5px 0 0 0; color: #94a3b8; font-size: 0.9rem;">Consolidated dashboard for custom RAG search, itineraries, and destination comparisons.</p>
</div>
""", unsafe_allow_html=True)

# ----------------- MAIN 2-COLUMN LAYOUT -----------------
left_col, right_col = st.columns([1, 2], gap="large")

# ==================== LEFT COLUMN: SETUP & UPLOADS ====================
with left_col:
    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.subheader("Step 1: Configuration & Uploads")
    
    # 1. API Key Config
    api_key_val = st.text_input(
        "Gemini API Key (Optional)",
        value=st.session_state.api_key,
        type="password",
        help="Input your Gemini API key to activate real AI logic. Leaving it empty runs in local Demo Mock Mode."
    )
    if api_key_val != st.session_state.api_key:
        st.session_state.api_key = api_key_val.strip()
        st.success("API Key updated!")
        st.rerun()
        


    # Rate-limit / Free Tier Optimizations
    use_semantic = st.checkbox(
        "Use Semantic Search (Requires API)",
        value=True,
        key="use_semantic",
        help="When checked, calls the Gemini embedding API. Uncheck to run search offline using keyword overlapping matching to save Free Tier API quota."
    )
        
    # Show active key status visually (no emojis)
    if st.session_state.api_key:
        st.markdown("""
        <div style="background-color: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981; padding: 10px; border-radius: 6px; font-weight: 600; text-align: center; font-size: 11px; margin-top: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
            [Active] Gemini API Key Detected
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div style="background-color: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); color: #f59e0b; padding: 10px; border-radius: 6px; font-weight: 600; text-align: center; font-size: 11px; margin-top: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
            [Demo Mode] Running in Offline Mock Mode
        </div>
        """, unsafe_allow_html=True)
        
    st.markdown("<hr style='margin: 15px 0; border: 0; border-top: 1px solid #334155;'/>", unsafe_allow_html=True)
    
    # 2. PDF Uploader
    uploaded_files = st.file_uploader(
        "Upload Travel Guide PDFs",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload travel brochures, schedules, or guideline documents to search them."
    )
    
    if uploaded_files:
        if st.button("Index Uploaded PDFs"):
            with st.spinner("Extracting text and vectorizing chunks..."):
                added_chunks = 0
                for u_file in uploaded_files:
                    file_path = settings.UPLOAD_DIR / u_file.name
                    with file_path.open("wb") as buffer:
                        buffer.write(u_file.read())
                    
                    chunks = extract_text_chunks_from_pdf(file_path, u_file.name)
                    vector_store.add_chunks(chunks, api_key=st.session_state.api_key)
                    added_chunks += len(chunks)
                    
                st.success(f"Indexed {len(uploaded_files)} PDF(s) into {added_chunks} segments!")
                st.rerun()
                
    st.markdown("<hr style='margin: 15px 0; border: 0; border-top: 1px solid #334155;'/>", unsafe_allow_html=True)
    
    # 3. Active Guides List
    st.write("##### Active Travel Guides:")
    if total_docs > 0:
        st.info(f"Database contains {total_docs} files ({total_chunks} search segments).")
        for f in indexed_files:
            st.markdown(f"- **{f['filename']}**  \n  *{f['page_count']} pages | {f['chunk_count']} index chunks*")
            
        if st.button("Reset / Clear Database"):
            if settings.UPLOAD_DIR.exists():
                for child in settings.UPLOAD_DIR.iterdir():
                    if child.is_file():
                        child.unlink()
            vector_store.clear()
            st.success("Vector database reset!")
            st.rerun()
    else:
        st.write("No files uploaded yet. Upload PDFs above to activate search.")
        
    st.markdown('</div>', unsafe_allow_html=True)


# ==================== RIGHT COLUMN: TRIP PLANNER WORKSPACES ====================
with right_col:
    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.subheader("Step 2: Travel Planner Workspace")
    
    tab_chat, tab_itinerary, tab_compare = st.tabs([
        "Chat Q&A Workspace", 
        "Itinerary Generator", 
        "Destination Comparer"
    ])
    
    # ----------------- TAB: CHAT / Q&A -----------------
    with tab_chat:
        st.write("Submit free-text queries to look up details in indexed documents. The system uses RAG and provides references.")
        
        # Chat history
        for msg in st.session_state.chat_history:
            if msg["sender"] == "user":
                st.markdown(f'<div class="user-bubble"><strong>User:</strong><br/>{msg["text"]}</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="agent-bubble">', unsafe_allow_html=True)
                st.markdown(f"**Travel Assistant AI:**")
                st.markdown(msg["text"])
                
                # Expandable Agent thought logs
                if msg.get("logs") and len(msg["logs"]) > 0:
                    with st.expander("View AI Routing Logs"):
                        for log in msg["logs"]:
                            st.write(f"- **[{log['agent']}]**: {log['message']}")
                            
                # Expandable Sources Cited
                if msg.get("sources") and len(msg["sources"]) > 0:
                    st.write("**Sources Cited:**")
                    cols = st.columns(min(len(msg["sources"]), 3))
                    for s_idx, src in enumerate(msg["sources"]):
                        col_target = cols[s_idx % len(cols)]
                        with col_target:
                            if st.button(f"Doc: {src['filename']} (p. {src['page']})", key=f"src_{s_idx}_{datetime.now().microsecond}"):
                                st.info(f"Relevance Score: {src['score']}\n\nExcerpt:\n\"{src['text']}\"")
                st.markdown('</div>', unsafe_allow_html=True)
                
        # Chat input box
        chat_q = st.chat_input("Submit query (e.g., 'What are key sights in Delhi?', 'Dehradun itinerary details from PDF'...)")
        if chat_q:
            st.session_state.chat_history.append({"sender": "user", "text": chat_q})
            st.markdown(f'<div class="user-bubble"><strong>User:</strong><br/>{chat_q}</div>', unsafe_allow_html=True)
            
            with st.spinner("AI Router executing agent workflow..."):
                response = agent_service.run_workflow(
                    query=chat_q, 
                    api_key=st.session_state.api_key, 
                    model_name=st.session_state.model_name,
                    use_semantic=st.session_state.use_semantic
                )
                
            st.session_state.chat_history.append({
                "sender": "assistant",
                "text": response["text"],
                "logs": response.get("logs", []),
                "sources": response.get("sources", []),
            })
            st.rerun()

    # ----------------- TAB: ITINERARY PLANNER -----------------
    with tab_itinerary:
        st.write("Generate an itemized day-by-day travel plan with corresponding weather forecasts and budget allocations.")
        
        # Simple Form
        iti_col1, iti_col2 = st.columns(2)
        with iti_col1:
            iti_dest = st.text_input("Destination City/Country", "Dehradun")
            iti_days = st.slider("Duration (Days)", 1, 10, 5)
        with iti_col2:
            iti_style = st.selectbox("Budget Style Tier", ["Budget", "Mid-Range", "Luxury"], index=1)
            iti_travelers = st.number_input("Travelers Count", min_value=1, max_value=10, value=2)
            
        if st.button("Generate Plan"):
            style_map = {"Budget": "budget", "Mid-Range": "mid_range", "Luxury": "luxury"}
            style_param = style_map[iti_style]
            query = f"Generate a detailed day-by-day itinerary for {iti_dest} for {iti_days} days with {style_param} travel style for {iti_travelers} traveler(s)."
            
            with st.spinner("Coordinating tools and generating plan..."):
                response = agent_service.run_workflow(
                    query=query, 
                    api_key=st.session_state.api_key, 
                    model_name=st.session_state.model_name,
                    category="itinerary",
                    destinations=[iti_dest],
                    duration_days=iti_days,
                    travel_style=style_param,
                    num_travelers=iti_travelers,
                    use_semantic=st.session_state.use_semantic
                )
                
            tool_data = response.get("tool_data", {})
            
            # Display Quick Weather & Budget Cards
            card_col1, card_col2 = st.columns(2)
            with card_col1:
                if tool_data.get("weather") and len(tool_data["weather"]) > 0:
                    w = tool_data["weather"][0]
                    st.markdown(f"""
                    <div style="background-color: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 12px; margin-bottom: 15px;">
                        <span style="font-size: 10px; color: #14b8a6; font-weight: 500; text-transform: uppercase;">Forecast Summary</span>
                        <h4 style="margin: 2px 0; color: white;">{w['location']}</h4>
                        <p style="margin: 2px 0 0 0; font-size: 11px;">Temperature: {w['current']['temp']}°C | Condition: {w['current']['condition']}</p>
                    </div>
                    """, unsafe_allow_html=True)
            with card_col2:
                if tool_data.get("budget") and len(tool_data["budget"]) > 0:
                    b = tool_data["budget"][0]
                    st.markdown(f"""
                    <div style="background-color: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 12px; margin-bottom: 15px;">
                        <span style="font-size: 10px; color: #6366f1; font-weight: 500; text-transform: uppercase;">Estimated Cost Breakdown</span>
                        <h4 style="margin: 2px 0; color: white;">Rs. {b['totals']['total_excluding_flights']} INR (excl. flights)</h4>
                        <p style="margin: 2px 0 0 0; font-size: 11px;">Average: Rs. {b['daily_breakdown']['total_daily']} INR/day for {iti_travelers} travelers</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
            # Render visual timeline
            st.markdown("##### Timeline Activities:")
            blocks = response["text"].split('###')
            if len(blocks) <= 1:
                st.write(response["text"])
            else:
                st.write(blocks[0]) # Intro paragraph
                for block in blocks[1:]:
                    line_end = block.find('\n')
                    title = block[:line_end].strip()
                    content = block[line_end:].strip()
                    
                    st.markdown(f"""
                    <div class="timeline-block">
                        <div class="timeline-dot"></div>
                        <strong style="color: #6366f1; font-size: 13px;">{title}</strong>
                        <p style="margin: 3px 0 0 0; font-size: 12px; color: #cbd5e1;">{content}</p>
                    </div>
                    """, unsafe_allow_html=True)

    # ----------------- TAB: DESTINATION COMPARER -----------------
    with tab_compare:
        st.write("Compare budgets, weather outlooks, visa rules, and safety alerts side-by-side.")
        
        comp_col1, comp_col2 = st.columns(2)
        with comp_col1:
            dest_A = st.text_input("First Destination", "Delhi")
            comp_days_val = st.slider("Trip Length (Days)", 1, 15, 5, key="comp_days_iti")
        with comp_col2:
            dest_B = st.text_input("Second Destination", "Dehradun")
            comp_style_val = st.selectbox("Travel Tier Style", ["Budget", "Mid-Range", "Luxury"], index=1, key="comp_style_iti")
            
        if st.button("Run Comparison"):
            with st.spinner("Analyzing metrics..."):
                style_param = {"Budget": "budget", "Mid-Range": "mid_range", "Luxury": "luxury"}[comp_style_val]
                
                # Fetch tools directly (bypassing LLM router calls)
                budgetA = calculate_trip_budget(dest_A, comp_days_val, style_param)
                budgetB = calculate_trip_budget(dest_B, comp_days_val, style_param)
                
                weatherA = fetch_weather_forecast(dest_A)
                weatherB = fetch_weather_forecast(dest_B)
                
                guidelinesA = retrieve_travel_guidelines(dest_A)
                guidelinesB = retrieve_travel_guidelines(dest_B)
                
                # Generate AI advisory comparison
                query = f"Compare {dest_A} and {dest_B} for a {comp_days_val}-day trip under travel style {style_param}. Highlight key differences in safety, attractions, and vibe."
                chat_res = agent_service.run_workflow(
                    query=query, 
                    api_key=st.session_state.api_key, 
                    model_name=st.session_state.model_name,
                    category="compare",
                    destinations=[dest_A, dest_B],
                    duration_days=comp_days_val,
                    travel_style=style_param,
                    use_semantic=st.session_state.use_semantic
                )
                
            # Render Comparative Grid (clean UI typography)
            c_col1, c_col2 = st.columns(2)
            with c_col1:
                st.markdown(f"#### {budgetA['destination']}")
                st.write(f"- **Est. Budget**: **Rs. {budgetA['totals']['total_excluding_flights']}**")
                st.write(f"- **Current Temp**: {weatherA['current']['temp']}°C ({weatherA['current']['condition']})")
                st.write(f"- **Visa Advisory**: {guidelinesA['visa_requirements'][:100]}...")
                st.write(f"- **Safety**: {guidelinesA['safety_advisory']}")
            with c_col2:
                st.markdown(f"#### {budgetB['destination']}")
                st.write(f"- **Est. Budget**: **Rs. {budgetB['totals']['total_excluding_flights']}**")
                st.write(f"- **Current Temp**: {weatherB['current']['temp']}°C ({weatherB['current']['condition']})")
                st.write(f"- **Visa Advisory**: {guidelinesB['visa_requirements'][:100]}...")
                st.write(f"- **Safety**: {guidelinesB['safety_advisory']}")
                
            st.markdown("<hr style='margin: 15px 0; border: 0; border-top: 1px solid #334155;'/>", unsafe_allow_html=True)
            st.write("##### AI Comparison Analysis Summary:")
            st.write(chat_res["text"])

    st.markdown('</div>', unsafe_allow_html=True)
