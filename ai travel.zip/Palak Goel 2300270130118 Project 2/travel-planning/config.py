import os
from pathlib import Path
from dotenv import load_dotenv

# Load standard .env relative to config file location
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(dotenv_path=BASE_DIR / ".env")

class Settings:
    BASE_DIR = Path(__file__).resolve().parent
    UPLOAD_DIR = BASE_DIR / "data" / "uploads"
    INDEX_PATH = BASE_DIR / "data" / "vector_store.json"
    
    def __init__(self):
        # Ensure directories exist
        self.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

    # API configuration
    DEFAULT_GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "") or os.getenv("GOOGLE_API_KEY", "")
    DEFAULT_MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite")
    
    # Text chunking options
    CHUNK_SIZE = 800
    CHUNK_OVERLAP = 150
    
settings = Settings()
