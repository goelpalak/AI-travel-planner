import json
import logging
import math
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
import numpy as np
import google.generativeai as genai
from config import settings

logger = logging.getLogger(__name__)

class VectorStore:
    def __init__(self, index_path: Path = settings.INDEX_PATH):
        self.index_path = index_path
        self.chunks: List[Dict[str, Any]] = []
        self.embeddings: List[List[float]] = []
        self.load()

    def load(self):
        """Loads chunks and embeddings from disk if they exist."""
        if self.index_path.exists():
            try:
                with open(self.index_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.chunks = data.get("chunks", [])
                    self.embeddings = data.get("embeddings", [])
                logger.info(f"Loaded {len(self.chunks)} chunks from {self.index_path}")
            except Exception as e:
                logger.error(f"Error loading vector store index: {e}")
                self.chunks = []
                self.embeddings = []

    def save(self):
        """Saves chunks and embeddings to disk."""
        try:
            self.index_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.index_path, "w", encoding="utf-8") as f:
                json.dump({
                    "chunks": self.chunks,
                    "embeddings": self.embeddings
                }, f, ensure_ascii=False)
            logger.info(f"Saved {len(self.chunks)} chunks to {self.index_path}")
        except Exception as e:
            logger.error(f"Error saving vector store index: {e}")

    def clear(self):
        """Clears the vector store."""
        self.chunks = []
        self.embeddings = []
        if self.index_path.exists():
            try:
                self.index_path.unlink()
            except Exception as e:
                logger.error(f"Error deleting index file: {e}")

    def _get_embedding(self, text: str, api_key: str) -> Optional[List[float]]:
        """Generates embedding using Gemini API."""
        try:
            genai.configure(api_key=api_key)
            result = genai.embed_content(
                model="models/text-embedding-004",
                content=text,
                task_type="retrieval_document"
            )
            return result.get("embedding", None)
        except Exception as e:
            logger.error(f"Gemini embedding generation error: {e}")
            return None

    def add_chunks(self, new_chunks: List[Dict[str, Any]], api_key: Optional[str] = None):
        """
        Adds new chunks to the vector store.
        If api_key is provided, embeddings are generated. Otherwise, dummy zero embeddings are added.
        """
        active_key = api_key or settings.DEFAULT_GEMINI_API_KEY
        
        for i, chunk in enumerate(new_chunks):
            # Check if chunk already exists
            if any(existing["id"] == chunk["id"] for existing in self.chunks):
                continue
                
            text = chunk["text"]
            embedding = None
            
            if active_key:
                embedding = self._get_embedding(text, active_key)
                
            if embedding is None:
                # Fallback: create a zero embedding or None
                embedding = []
                
            self.chunks.append(chunk)
            self.embeddings.append(embedding)
            
        self.save()

    def search(self, query: str, k: int = 5, api_key: Optional[str] = None) -> List[Tuple[Dict[str, Any], float]]:
        """
        Searches the vector store for top k matching chunks.
        If api_key is available, uses vector cosine similarity.
        Otherwise, falls back to text-based similarity (keyword overlap).
        """
        if not self.chunks:
            return []
            
        active_key = api_key or settings.DEFAULT_GEMINI_API_KEY
        
        # Check if we have valid embeddings for all items and if API key is provided
        has_embeddings = len(self.embeddings) > 0 and len(self.embeddings[0]) > 0
        
        if active_key and has_embeddings:
            try:
                genai.configure(api_key=active_key)
                result = genai.embed_content(
                    model="models/text-embedding-004",
                    content=query,
                    task_type="retrieval_query"
                )
                query_emb = result.get("embedding", None)
                
                if query_emb:
                    return self._vector_search(query_emb, k)
            except Exception as e:
                logger.warning(f"Embedding search failed, falling back to keyword search: {e}")
                
        # Fallback keyword search
        return self._keyword_search(query, k)

    def _vector_search(self, query_emb: List[float], k: int) -> List[Tuple[Dict[str, Any], float]]:
        """Calculates cosine similarity between query embedding and stored embeddings."""
        q_vec = np.array(query_emb)
        q_norm = np.linalg.norm(q_vec)
        
        if q_norm == 0:
            return []
            
        scores = []
        for idx, emb in enumerate(self.embeddings):
            if not emb:
                scores.append(-1.0) # No embedding for this chunk
                continue
                
            e_vec = np.array(emb)
            e_norm = np.linalg.norm(e_vec)
            
            if e_norm == 0:
                scores.append(0.0)
                continue
                
            similarity = np.dot(q_vec, e_vec) / (q_norm * e_norm)
            scores.append(float(similarity))
            
        # Get top k indices
        top_indices = np.argsort(scores)[::-1][:k]
        results = []
        for idx in top_indices:
            if scores[idx] >= -0.5: # Valid similarity threshold
                results.append((self.chunks[idx], scores[idx]))
        return results

    def _keyword_search(self, query: str, k: int) -> List[Tuple[Dict[str, Any], float]]:
        """Fallback: basic text-based keyword matching similarity (TF-IDF light)."""
        # Tokenize and clean helper
        def tokenize(text: str) -> List[str]:
            return re.findall(r'\b\w+\b', text.lower())
            
        query_tokens = set(tokenize(query))
        if not query_tokens:
            return [(c, 0.0) for c in self.chunks[:k]]
            
        # Calculate term frequencies for chunks
        scores = []
        for chunk in self.chunks:
            chunk_tokens = tokenize(chunk["text"])
            if not chunk_tokens:
                scores.append(0.0)
                continue
                
            # Intersect count
            overlap = len(query_tokens.intersection(chunk_tokens))
            
            # Cosine-like keyword score: overlap / sqrt(len(query) * len(chunk))
            score = overlap / math.sqrt(len(query_tokens) * len(chunk_tokens))
            scores.append(score)
            
        # Sort and return top k
        top_indices = np.argsort(scores)[::-1][:k]
        results = []
        for idx in top_indices:
            if scores[idx] > 0.0:
                results.append((self.chunks[idx], scores[idx]))
                
        # If no overlaps found, return first few chunks as fallback
        if not results:
            return [(c, 0.0) for c in self.chunks[:k]]
            
        return results

# Singleton instance
vector_store = VectorStore()
