import json
import logging
import re
from typing import List, Dict, Any, Optional
import google.generativeai as genai
from config import settings
from services.vector_store import vector_store
from tools.weather_tool import fetch_weather_forecast
from tools.budget_tool import calculate_trip_budget
from tools.guidelines_tool import retrieve_travel_guidelines

logger = logging.getLogger(__name__)

class AgentService:
    def __init__(self):
        pass

    def run_workflow(
        self, 
        query: str, 
        api_key: Optional[str] = None, 
        model_name: Optional[str] = None,
        category: Optional[str] = None,
        destinations: Optional[List[str]] = None,
        duration_days: Optional[int] = 5,
        travel_style: Optional[str] = "mid_range",
        num_travelers: Optional[int] = 1,
        use_semantic: Optional[bool] = True
    ) -> Dict[str, Any]:
        """
        Executes the Agentic workflow.
        """
        logs = []
        tool_data = {"weather": [], "budget": [], "guidelines": []}
        sources = []
        
        active_key = api_key or settings.DEFAULT_GEMINI_API_KEY
        active_model = model_name or settings.DEFAULT_MODEL_NAME
        
        if not active_key:
            logs.append({"agent": "System", "message": "No API key provided. Activating Demo Mock Mode."})
            return self._run_mock_workflow(query, logs, tool_data, sources)
            
        # 1. Routing phase (Bypass LLM call if parameters are passed directly from UI forms)
        if category:
            route_info = {
                "categories": [category],
                "destinations": destinations or [],
                "duration_days": duration_days or 5,
                "travel_style": travel_style or "mid_range",
                "num_travelers": num_travelers or 1,
                "requires_rag": True
            }
            logs.append({"agent": "Router Agent", "message": f"Direct form parameters resolved (Router API call bypassed). Categories: {route_info['categories']}. Destinations: {route_info['destinations']}."})
        else:
            # Use local rule-based heuristics for free-text chat to save API quota
            route_info = self._heuristic_route_query(query)
            logs.append({"agent": "Router Agent", "message": f"Local heuristics resolved (Router API call bypassed). Categories: {route_info['categories']}. Destinations: {route_info['destinations']}."})
            
        destinations = route_info.get("destinations", [])
        duration_days = route_info.get("duration_days", 5)
        travel_style = route_info.get("travel_style", "mid_range")
        num_travelers = route_info.get("num_travelers", 1)
        categories = route_info.get("categories", ["chat"])
        
        # Ensure we have at least one destination if itinerary or budget is requested
        if not destinations:
            # Try to guess a destination or search it from query
            guessed = self._extract_destination_fallback(query)
            if guessed:
                destinations = [guessed]
                logs.append({"agent": "Router Agent", "message": f"Identified destination: '{guessed}'"})
                
        # 2. Execution phase: Call tools and fetch documents
        # Weather Tool
        if "weather" in categories or any(w in query.lower() for w in ["weather", "temp", "rain", "forecast"]):
            for dest in destinations:
                logs.append({"agent": "Weather Agent", "message": f"Fetching weather forecast for '{dest}'..."})
                w_info = fetch_weather_forecast(dest)
                tool_data["weather"].append(w_info)
                logs.append({"agent": "Weather Agent", "message": f"Current weather in {dest}: {w_info['current']['temp']}°C, {w_info['current']['condition']}."})
                
        # Budget Tool
        if "budget" in categories or any(b in query.lower() for b in ["budget", "cost", "price", "expensive", "cheap", "estimate"]):
            for dest in destinations:
                logs.append({"agent": "Budget Agent", "message": f"Estimating trip budget for '{dest}' ({travel_style.replace('_',' ').title()} style, {duration_days} days)..."})
                b_info = calculate_trip_budget(dest, duration_days, travel_style, num_travelers)
                tool_data["budget"].append(b_info)
                logs.append({"agent": "Budget Agent", "message": f"Budget summary: ${b_info['totals']['total_excluding_flights']} USD (excl. flights) total."})
                
        # Guidelines Tool
        if "guidelines" in categories or any(g in query.lower() for g in ["visa", "safety", "plug", "attractions", "sights", "see", "do"]):
            for dest in destinations:
                logs.append({"agent": "Guidelines Agent", "message": f"Retrieving travel guidelines and tourist attractions for '{dest}'..."})
                g_info = retrieve_travel_guidelines(dest)
                tool_data["guidelines"].append(g_info)
                logs.append({"agent": "Guidelines Agent", "message": f"Found {len(g_info.get('top_attractions', []))} attractions and safety info."})

        # RAG Retrieval
        rag_context = ""
        if route_info.get("requires_rag", True) or vector_store.chunks:
            logs.append({"agent": "RAG Retrieval Agent", "message": "Executing vector database semantic search..."})
            active_search_key = active_key if use_semantic else None
            search_results = vector_store.search(query, k=5, api_key=active_search_key)
            if search_results:
                logs.append({"agent": "RAG Retrieval Agent", "message": f"Retrieved {len(search_results)} relevant document segments."})
                context_blocks = []
                for chunk, score in search_results:
                    source_meta = chunk["metadata"]
                    context_blocks.append(f"Source: {source_meta['source']}, Page: {source_meta['page']}\nContent: {chunk['text']}")
                    sources.append({
                        "id": chunk["id"],
                        "filename": source_meta["source"],
                        "page": source_meta["page"],
                        "text": chunk["text"],
                        "score": round(score, 3)
                    })
                rag_context = "\n\n---\n\n".join(context_blocks)
            else:
                logs.append({"agent": "RAG Retrieval Agent", "message": "No relevant documents found in vector database."})
                
        # 3. Sub-agents and Synthesis phase
        logs.append({"agent": "Synthesis Agent", "message": "Generating final response..."})
        
        # Set up LLM parameters
        genai.configure(api_key=active_key)
        model = genai.GenerativeModel(active_model)
        
        synthesis_prompt = self._build_synthesis_prompt(
            query=query,
            categories=categories,
            destinations=destinations,
            duration_days=duration_days,
            travel_style=travel_style,
            num_travelers=num_travelers,
            tool_data=tool_data,
            rag_context=rag_context
        )
        
        try:
            response = model.generate_content(synthesis_prompt)
            final_text = response.text
        except Exception as e:
            logger.error(f"Synthesis generation failed: {e}")
            final_text = f"⚠️ **Gemini API Error:** {e}\n\n"
            if "404" in str(e) or "not found" in str(e).lower():
                final_text += (
                    "**Model Not Found (404) Hint:**\n"
                    f"The model `{active_model}` is not supported or accessible by your API Key.\n"
                    "**Please try changing the 'Gemini Model Selection' dropdown in the left column** (e.g., to `gemini-pro` or `gemini-2.0-flash-exp`) and query again.\n\n"
                )
            final_text += "Here is the raw data retrieved:\n"
            if tool_data["weather"]:
                final_text += f"\n**Weather**: {json.dumps(tool_data['weather'], indent=2)}"
            if tool_data["budget"]:
                final_text += f"\n**Budget**: {json.dumps(tool_data['budget'], indent=2)}"
            if sources:
                final_text += f"\n**Retrieved Excerpts**:\n"
                for src in sources:
                    final_text += f"- [{src['filename']} Page {src['page']}]: {src['text'][:150]}...\n"

        return {
            "text": final_text,
            "logs": logs,
            "tool_data": tool_data,
            "sources": sources
        }

    def _route_query(self, query: str, api_key: str, model_name: str) -> Dict[str, Any]:
        """Queries Gemini to route the query and extract travel parameters in JSON format."""
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel(model_name)
        
        router_prompt = f"""
        You are the Routing Agent of a Smart Travel Planner.
        Analyze the user's travel query and classify it.
        
        Query: "{query}"
        
        You must return a valid JSON object matching this structure EXACTLY:
        {{
          "categories": ["chat" | "itinerary" | "compare" | "budget" | "weather" | "guidelines"],
          "destinations": ["city or country name"],
          "duration_days": int (default is 5),
          "travel_style": "budget" | "mid_range" | "luxury",
          "num_travelers": int (default is 1),
          "requires_rag": boolean (set true if query relates to uploaded guides, local spots, custom itinerary, rules, attractions)
        }}
        
        Choose categories from:
        - "chat": basic questions, travel advice, queries about documents.
        - "itinerary": user asks for a day-by-day plan/itinerary.
        - "compare": user asks to compare two or more places (e.g. "Tokyo vs Kyoto").
        - "budget": user asks about costs, expenses, or budgets.
        - "weather": user asks about climate, rain, temperature, or forecasts.
        - "guidelines": user asks about safety, visa, customs, or tourist attractions.
        """
        
        response = model.generate_content(
            router_prompt,
            generation_config={"response_mime_type": "application/json"}
        )
        return json.loads(response.text)

    def _heuristic_route_query(self, query: str) -> Dict[str, Any]:
        """Fallback rule-based router if LLM router fails."""
        q = query.lower()
        categories = []
        
        if "itinerary" in q or "plan" in q or "schedule" in q or "trip" in q or "day" in q:
            categories.append("itinerary")
        if "compare" in q or "vs" in q or "better" in q or "difference" in q:
            categories.append("compare")
        if "budget" in q or "cost" in q or "price" in q or "expensive" in q or "cheap" in q or "estimate" in q:
            categories.append("budget")
        if "weather" in q or "temp" in q or "rain" in q or "climate" in q or "forecast" in q:
            categories.append("weather")
        if "visa" in q or "safety" in q or "guideline" in q or "attraction" in q or "sights" in q or "do" in q:
            categories.append("guidelines")
            
        if not categories:
            categories.append("chat")
            
        # Parse travel style
        style = "mid_range"
        if "luxury" in q or "premium" in q or "expensive" in q:
            style = "luxury"
        elif "budget" in q or "cheap" in q or "backpack" in q:
            style = "budget"
            
        # Parse days
        days = 5
        day_match = re.search(r'(\d+)\s*-?\s*day', q)
        if day_match:
            days = int(day_match.group(1))
            
        # Parse travelers
        travelers = 1
        t_match = re.search(r'(\d+)\s*(people|person|traveler|adult)', q)
        if t_match:
            travelers = int(t_match.group(1))
            
        destinations = []
        guessed = self._extract_destination_fallback(query)
        if guessed:
            destinations = [guessed]
            
        return {
            "categories": categories,
            "destinations": destinations,
            "duration_days": days,
            "travel_style": style,
            "num_travelers": travelers,
            "requires_rag": True
        }

    def _extract_destination_fallback(self, query: str) -> Optional[str]:
        """Extracts common destinations from a string using matching."""
        from tools.weather_tool import CITY_COORDINATES
        q = query.lower()
        for city in CITY_COORDINATES.keys():
            if city in q:
                return city
        return None

    def _build_synthesis_prompt(
        self, 
        query: str, 
        categories: List[str], 
        destinations: List[str], 
        duration_days: int, 
        travel_style: str, 
        num_travelers: int,
        tool_data: Dict[str, Any], 
        rag_context: str
    ) -> str:
        """Constructs a detailed system prompt for the synthesis agent."""
        
        # Format tool outputs nicely
        weather_str = ""
        if tool_data["weather"]:
            weather_str = "\n".join([f"Weather for {w['location']}:\n- Current: {w['current']['temp']}°C, {w['current']['condition']}\n- 5-Day Forecast: " + ", ".join([f"{f['date']}: {f['temp_max']}°C/{f['temp_min']}°C ({f['condition']})" for f in w['forecast']]) for w in tool_data["weather"]])
            
        budget_str = ""
        if tool_data["budget"]:
            budget_str = "\n".join([
                f"Budget for {b['destination']} ({b['travel_style']} style, {b['duration_days']} days, {b['num_travelers']} travelers):\n"
                f"- Daily categories: Accommodation={b['daily_breakdown']['accommodation']} INR/day, Food={b['daily_breakdown']['food']} INR/day, Transit={b['daily_breakdown']['transport']} INR/day, Activities={b['daily_breakdown']['activities']} INR/day.\n"
                f"- Totals: Accomodation Total={b['total_breakdown']['accommodation']} INR, Food Total={b['total_breakdown']['food']} INR, Transit Total={b['total_breakdown']['transport']} INR, Activities Total={b['total_breakdown']['activities']} INR, Flights Est={b['total_breakdown']['flights_estimate']} INR, Misc Buffer={b['total_breakdown']['misc_buffer']} INR.\n"
                f"- Grand Total (Excl Flights): Rs. {b['totals']['total_excluding_flights']}.\n"
                f"- Grand Total (Incl Flights): Rs. {b['totals']['total_including_flights']}."
                for b in tool_data["budget"]
            ])
            
        guidelines_str = ""
        if tool_data["guidelines"]:
            guidelines_str = "\n".join([
                f"Guidelines for {g['location']}:\n"
                f"- Visa: {g['visa_requirements']}\n"
                f"- Safety: {g['safety_advisory']}\n"
                f"- Power Sockets: {g['power_sockets']}\n"
                f"- Emergency Numbers: {g['emergency_numbers']}\n"
                f"- Top Attractions:\n" + "\n".join([f"  * {att['name']}: {att['desc']}" for att in g['top_attractions']])
                for g in tool_data["guidelines"]
            ])

        prompt = f"""
        You are the Synthesis Agent of a premium AI Travel Assistant. Your job is to generate a comprehensive, visually stunning, and highly structured travel response. All budgets and cost estimates must be presented in Indian Rupees (INR) with Rs. notation. Do not use USD.
        
        User Query: "{query}"
        
        Here is the data collected from your routing sub-agents and tools:
        
        === WEATHER TOOL DATA ===
        {weather_str or "No weather data retrieved."}
        
        === BUDGET TOOL DATA ===
        {budget_str or "No budget data retrieved."}
        
        === GUIDELINES & SIGHTS DATA ===
        {guidelines_str or "No guidelines/attraction data retrieved."}
        
        === RAG CONTEXT (FROM UPLOADED GUIDE DOCUMENTS) ===
        {rag_context or "No custom travel guide documents retrieved."}
        
        ====================================================
        
        INSTRUCTIONS FOR YOUR RESPONSE:
        
        1. **Structured Layout**: Use beautiful markdown structure. Include sections, bullet points, code blocks for tables, bold text, and horizontal rules to make the response read like a premium travel advisory brochure.
        
        2. **Citations (CRITICAL)**: If you are using information from the "RAG CONTEXT", you MUST cite the source document. Use the notation `[source: filename.pdf, p. page_number]` inline where you make the claim.
           Example: "According to the guide, Kyoto's temples close early in the evening [source: japan_guide.pdf, p. 12]."
           Only cite when using text from the RAG CONTEXT. Do not cite general tool data.
           
        3. **Tone**: Warm, helpful, expert travel planner.
        
        4. **Itineraries**: If the user requested an itinerary, outline a clean day-by-day plan with specific times/suggestions, utilizing the attractions found in the guidelines or RAG context. Do not use any icons or emojis. Keep the formatting clean and text-only.
        
        5. **Comparisons**: If the user requested a comparison, create a side-by-side markdown comparison table showing factors like Average Daily Budget (in INR), Weather conditions, Key Attractions, Safety index, and Visa requirements. Do not use emojis in headers or content. Add a clear "Recommendation Summary" at the end.
        
        Generate the final response:
        """
        return prompt

    def _run_mock_workflow(self, query: str, logs: List[Dict], tool_data: Dict, sources: List) -> Dict[str, Any]:
        """Generates detailed responses in offline/demo mock mode without an API key."""
        q = query.lower()
        logs.append({"agent": "Router Agent (Mock)", "message": "Using local heuristics to parse query parameters."})
        
        # Route logic
        route = self._heuristic_route_query(query)
        destinations = route["destinations"]
        if not destinations:
            destinations = ["Tokyo"] # Fallback default
            
        logs.append({"agent": "Router Agent (Mock)", "message": f"Mock routing determined: Destinations={destinations}, Style={route['travel_style']}, Duration={route['duration_days']} days."})
        
        # Call mock tools
        for dest in destinations:
            logs.append({"agent": "Weather Agent (Mock)", "message": f"Fetching mock weather forecast for '{dest}'..."})
            w_info = fetch_weather_forecast(dest)
            tool_data["weather"].append(w_info)
            
            logs.append({"agent": "Budget Agent (Mock)", "message": f"Calculating mock budget for '{dest}'..."})
            b_info = calculate_trip_budget(dest, route["duration_days"], route["travel_style"], route["num_travelers"])
            tool_data["budget"].append(b_info)
            
            logs.append({"agent": "Guidelines Agent (Mock)", "message": f"Retrieving travel guidelines and attractions for '{dest}'..."})
            g_info = retrieve_travel_guidelines(dest)
            tool_data["guidelines"].append(g_info)

        # Mock RAG Retrieval
        logs.append({"agent": "RAG Retrieval Agent (Mock)", "message": "Performing mock database keyword match..."})
        search_results = vector_store.search(query, k=3, api_key=None)
        
        rag_text_display = ""
        if search_results:
            logs.append({"agent": "RAG Retrieval Agent (Mock)", "message": f"Retrieved {len(search_results)} matching blocks from local index."})
            context_blocks = []
            for chunk, score in search_results:
                source_meta = chunk["metadata"]
                context_blocks.append(f"Source: {source_meta['source']}, Page: {source_meta['page']}\nContent: {chunk['text']}")
                sources.append({
                    "id": chunk["id"],
                    "filename": source_meta["source"],
                    "page": source_meta["page"],
                    "text": chunk["text"],
                    "score": round(score, 3)
                })
            
            # Format display block for final text
            rag_text_display = "\n\n### 📖 Relevant Travel Guide Excerpts\n"
            for src in sources:
                rag_text_display += f"> **{src['filename']} (p. {src['page']})**:\n> \"{src['text']}\"\n>\n"
        else:
            logs.append({"agent": "RAG Retrieval Agent (Mock)", "message": "No relevant local documents parsed."})

        # Synthesize Mock Response
        dest_title = destinations[0].title()
        weather_desc = tool_data["weather"][0]["current"]["condition"]
        weather_temp = tool_data["weather"][0]["current"]["temp"]
        budget_total = tool_data["budget"][0]["totals"]["total_excluding_flights"]
        style_title = route["travel_style"].replace("_", " ").title()
        
        text = f"""# ✈️ Travel Assistant Response (Demo Mock Mode)

*Note: The application is running in **Demo Mock Mode** because a Gemini API Key has not been configured. All responses are synthesized programmatically using local heuristics and databases.*

---

## 📍 Destination: {dest_title}

### ☀️ Weather & Climate Forecast
The current weather in **{dest_title}** is **{weather_temp}°C** and **{weather_desc}**.
Here is the 5-day outlook:
"""
        for f in tool_data["weather"][0]["forecast"]:
            text += f"- **{f['date']}**: {f['temp_max']}°C / {f['temp_min']}°C — {f['condition']} (Precipitation: {f['precipitation_prob']}%)\n"

        text += f"""
### Estimated Trip Budget ({style_title} Style)
- **Duration**: {route["duration_days"]} Days
- **Travelers**: {route["num_travelers"]} Person(s)
- **Daily Average (Per Person)**: Rs. {tool_data["budget"][0]["daily_breakdown"]["total_daily"]} INR
- **Total Estimated Cost (Excl. Flights)**: **Rs. {budget_total} INR**
- **Flight Baseline Estimate**: Rs. {tool_data["budget"][0]["total_breakdown"]["flights_estimate"]} INR
- **Buffer / Emergency Margin**: Rs. {tool_data["budget"][0]["total_breakdown"]["misc_buffer"]} INR

| Expense Category | Daily Estimate | Total Estimate |
| :--- | :--- | :--- |
| Accommodation | Rs. {tool_data["budget"][0]["daily_breakdown"]["accommodation"]} INR | Rs. {tool_data["budget"][0]["total_breakdown"]["accommodation"]} INR |
| Food & Dining | Rs. {tool_data["budget"][0]["daily_breakdown"]["food"]} INR | Rs. {tool_data["budget"][0]["total_breakdown"]["food"]} INR |
| Local Transit | Rs. {tool_data["daily_breakdown"]["transport"] if "daily_breakdown" in tool_data else tool_data["budget"][0]["daily_breakdown"]["transport"]} INR | Rs. {tool_data["budget"][0]["total_breakdown"]["transport"]} INR |
| Sightseeing & Tours | Rs. {tool_data["budget"][0]["daily_breakdown"]["activities"]} INR | Rs. {tool_data["budget"][0]["total_breakdown"]["activities"]} INR |

---

## Travel Itinerary & Highlights ({route["duration_days"]} Days)
Here is a recommended day-by-day plan:
"""
        attractions = tool_data["guidelines"][0]["top_attractions"]
        for i in range(1, route["duration_days"] + 1):
            text += f"""
#### Day {i}: Explore & Discover
- **08:30 AM** - Breakfast at a local cafe and daily briefing.
- **10:00 AM** - Visit **{attractions[(i-1) % len(attractions)]['name']}**
  - *Detail: {attractions[(i-1) % len(attractions)]['desc']}*
- **12:30 PM** - Lunch nearby tasting regional specialties.
- **02:00 PM** - Leisure stroll around the cultural quarters and scenic parks.
- **04:30 PM** - Explore local shopping galleries and artisan markets.
- **07:30 PM** - Traditional dinner reflecting your `{route["travel_style"]}` budget style.
"""
            
        text += f"""
---

## Travel Guidelines & Safety Advisory
- **Visa Requirements**: {tool_data["guidelines"][0]["visa_requirements"]}
- **Safety Advisory**: {tool_data["guidelines"][0]["safety_advisory"]}
- **Power Sockets & Plugs**: {tool_data["guidelines"][0]["power_sockets"]}
- **Local Emergency Lines**: {tool_data["guidelines"][0]["emergency_numbers"]}
"""
        
        if "compare" in route["categories"] and len(destinations) > 1:
            dest2 = destinations[1].title()
            b2_info = tool_data["budget"][1] if len(tool_data["budget"]) > 1 else calculate_trip_budget(dest2, route["duration_days"], route["travel_style"])
            w2_info = tool_data["weather"][1] if len(tool_data["weather"]) > 1 else fetch_weather_forecast(dest2)
            g2_info = tool_data["guidelines"][1] if len(tool_data["guidelines"]) > 1 else retrieve_travel_guidelines(dest2)
            
            text += f"""
---

## Destination Comparison: {dest_title} vs {dest2}

| Feature | {dest_title} | {dest2} |
| :--- | :--- | :--- |
| **Est. Daily Cost (Per Person)** | Rs. {tool_data["budget"][0]["daily_breakdown"]["total_daily"]} INR | Rs. {b2_info["daily_breakdown"]["total_daily"]} INR |
| **Est. Total Trip Cost (Excl. Flight)** | Rs. {budget_total} INR | Rs. {b2_info["totals"]["total_excluding_flights"]} INR |
| **Current Weather Conditions** | {weather_temp}°C, {weather_desc} | {w2_info["current"]["temp"]}°C, {w2_info["current"]["condition"]} |
| **Visa Regulations** | No visa required (Domestic Indian travel) | No visa required (Domestic Indian travel) |
| **Safety Advisory** | {tool_data["guidelines"][0]["safety_advisory"][:40]}... | {g2_info["safety_advisory"][:40]}... |
| **Highlight Attraction** | {attractions[0]["name"]} | {g2_info["top_attractions"][0]["name"]} |
"""

        # Append source excerpts if retrieved
        if rag_text_display:
            text += rag_text_display
            
        logs.append({"agent": "Synthesis Agent (Mock)", "message": "Final mock response compiled."})
        return {
            "text": text,
            "logs": logs,
            "tool_data": tool_data,
            "sources": sources
        }

# Singleton instance
agent_service = AgentService()
