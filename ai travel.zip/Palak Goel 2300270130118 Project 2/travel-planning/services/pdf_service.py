import re
from pathlib import Path
from typing import List, Dict, Any
from PyPDF2 import PdfReader
from config import settings

def extract_text_chunks_from_pdf(file_path: Path, filename: str) -> List[Dict[str, Any]]:
    """
    Extracts text from a PDF file page by page and splits it into
    overlapping chunks, preserving page references.
    """
    reader = PdfReader(file_path)
    chunks = []
    chunk_index = 0

    for page_idx, page in enumerate(reader.pages):
        page_number = page_idx + 1
        text = page.extract_text() or ""
        
        # Clean extra whitespaces
        text = re.sub(r'\s+', ' ', text).strip()
        if not text:
            continue
            
        # Segment the page text into chunks of specified size and overlap
        page_chunks = split_text_into_chunks(text, settings.CHUNK_SIZE, settings.CHUNK_OVERLAP)
        
        for p_chunk in page_chunks:
            chunks.append({
                "id": f"{filename}_p{page_number}_c{chunk_index}",
                "text": p_chunk,
                "metadata": {
                    "source": filename,
                    "page": page_number,
                    "chunk_idx": chunk_index
                }
            })
            chunk_index += 1
            
    return chunks

def split_text_into_chunks(text: str, chunk_size: int, overlap: int) -> List[str]:
    """
    Splits text into chunks of roughly `chunk_size` characters
    with a given `overlap` character count.
    """
    if len(text) <= chunk_size:
        return [text]
        
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        
        # Try to align chunk endings to sentence or word boundaries if possible
        if end < len(text):
            # Look backwards up to 100 characters for a sentence boundary (.!?) or space
            boundary = -1
            for offset in range(100):
                pos = end - offset
                if pos <= start:
                    break
                if text[pos] in ['.', '!', '?'] and (pos + 1 == len(text) or text[pos + 1].isspace()):
                    boundary = pos + 1
                    break
                if text[pos].isspace() and boundary == -1:
                    boundary = pos
            
            if boundary != -1:
                end = boundary
                
        chunks.append(text[start:end].strip())
        
        # If we reached the end, break
        if end >= len(text):
            break
            
        # Move start point back by overlap, ensuring we make progress
        next_start = end - overlap
        if next_start <= start:
            start = end
        else:
            start = next_start
            
    return chunks
